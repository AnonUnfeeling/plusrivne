package com.example.jdroidcoder.directory;

import java.util.ArrayList;

public class JSONNotificationModelFromInfo {
    private ArrayList<JSONNotificationModelFromClient.InfoModel> info;

    public ArrayList<JSONNotificationModelFromClient.InfoModel> getInfo() {
        return info;
    }

    public void setInfo(ArrayList<JSONNotificationModelFromClient.InfoModel> info) {
        this.info = info;
    }
}
